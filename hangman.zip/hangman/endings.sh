mistakes0() {
  ending_output="Perfekt! 👍 Du hast das Wort ohne Fehler erraten."
}
mistakes1() {
  ending_output="Wegen dieses einen Fehlers hast du es leider nicht fehlerfrei geschafft."
}
mistakes2() {
  ending_output="Das kannst du mit weniger Fehlern!"
}
mistakes3() {
  ending_output="Geschafft, aber mit vielen Fehlern. Übung macht den Meister."
}
mistakes4() {
  ending_output="Wenn du nochmal so viele Fehler machst, wird es aber knapp. 😡"
}
mistakes5() {
  ending_output="Kopf hoch, das war nicht das Ende."
}
